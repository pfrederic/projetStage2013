<?php
include ('header.html');//En-tête html
include ('fonction.php');//Pour utiliser des fonctions

//Fonction qui s'assure que la personne est bien connecté
verifLog();

//Si l'utilisateur tente d'accéder à la page sans avoir choisi au préalable un atelier
if(!isset($_SESSION['atelier']) || (empty($_SESSION['atelier'])))
{//début if
	header('location:menu.php');//redirection vers la page menu.php
}//fin if

//Si le formulaire de modifcation d'appréciation a été posté.
if(isset($_POST['action']) && $_POST['action']=="Modifier")
{//début if
	//appel de la fonction d'ajout ou de modification d'appréciation
	ajoutOuModif();
}//fin if

//Si le formulaire d'ajout d'un élève a été posté.
if(isset($_POST['action']) && $_POST['action']=="ok !")
{//début if
	//appel de la fonction d'ajout un élève
	ajoutEleve($_SESSION['atelier'],$_POST['lstElevesParClasse']);
}//fin if

//Si le formulaire de suppression d'un élève a été posté
if(isset($_POST['action']) && $_POST['action']=="Supprimer")
{//début if
	//appel de la fonction de la suppression d'un élève
	supprimerEleve();
}//fin if

//Permet de connaitre le nom de l'atelier le nom de l'atelier
$nomAtelier=connaitreNomAtelier();

//Affiche le nom de l'atelier
?>
<h1>Gestion <?=$nomAtelier?></h1>
<form name="selectionTrimestre" method="POST" action="">
<?
//appel de la fonction qui génére la liste déroulante des trimestre
listeTrimestre();
//Affiche les élèves présent pour l'atelier choisi
?>
<input type="submit" name="action" value="==>" />
</form>
<?
//Si le formulaire du choix d'un trismestre a été posté
if((isset($_POST['action']) && ($_POST['action']=="==>")) || (isset($_SESSION['trimestre'])))
{//début if
	?>
	<!-- Tableau -->
	<table>
		<thead>
			<tr>
				<th>Id</th>
				<th>Nom</th>
				<th>Prenom</th>
				<th>Date naissance</th>
				<th>Adresse</th>
				<th>Code postal</th>
				<th>Ville</th>
				<th>Mail</th>
				<th>Classe</th>
				<th>Appréciation</th>
				<th>Modifier</th>
				<?
				//Si l'utilisateur connecté posséde les droits suffissant, il peut accéder à d'autre fonctionnalité,
				//Ici, se sont seuleument l'ajout d'en-tête
				if($_SESSION['droit']==1)
				{//début if
				?>
					<th>Supprimer</th>
					<th>Bulletin</th>
				<?
				}//fin if
				?>			
			</tr>
		</thead>
		<tbody>
<?
	//Requete pour connaitre les élèves de l'atelier selon le stage
	$requete="SELECT Eleves.*, affAppreciation FROM Eleves NATURAL JOIN Affectation WHERE ateId='".$_SESSION['atelier']."' AND trimesId='".$_SESSION['trimestre']."';";
	$resultat=mysql_query($requete);
	//Boucle qui parcours les occurences de la base de données, selon la requête
	while($maLigne=mysql_fetch_array($resultat))
	{//début while
		$date=dateINFO2FR($maLigne["elvDateNaissance"]);
		if($maLigne["classeId"]==0)
		{//début if
			$classe=siTerminal($maLigne["classeId"]);
		}//fin if
		else
		{//début else
			$classe=$maLigne["classeId"];
		}//fin else
?>
			<tr>
				<td><?=$maLigne["elvId"]?></td>
				<td><?=$maLigne["elvNom"]?></td>
				<td><?=$maLigne["elvPrenom"]?></td>
				<td><?=$date?></td>
				<td><?=$maLigne["elvAdresse1"].=$maLigne["elvAdresse2"]?></td>
				<td><?=$maLigne["elvCp"]?></td>
				<td><?=$maLigne["elvVille"]?></td>
				<td><?=$maLigne["elvMail"]?></td>
				<td><?=$classe?></td>
				<!-- Formulaire d'ajout d'un appréciation -->
				<form name="saisieAppreciation" method="POST" action="">
				<input type="hidden" name="hiddenElvId" value="<?=$maLigne["elvId"]?>" />
				<td><textarea type="text" name="inputAppreciation" rows="3" cols="40" placeholder="Saisissez l'appréciation de l'elève" /><?=$maLigne["affAppreciation"]?></textarea></td>
				<td><input type="submit" name="action" value="Modifier" />
				</form>
				<?
				//Si l'utilisateur connecté posséde les droits suffissant, il peut accéder à d'autre fonctionnalité,
				//Ici, se sont de nouveaux formulaire
				if($_SESSION['droit']==1)
				{//début if
				?>
					<!-- Formulaire supprimer -->
					<form name="supprimerEleve" method="POST" action="">
					<td><input type="submit" name="action" value="Supprimer" /></td>
					<input type="hidden" name="hiddenElvId" value="<?=$maLigne["elvId"]?>" />
					</form>
					<!-- Formualire pour générer le bulletin de l'élève -->
					<form name="genePDF" method="POST" action="genePDF.php">
					<input type="hidden" name="hiddenElvId" value="<?=$maLigne["elvId"]?>" />
					<td><input type="submit" name="action" value="Générer le bulletin" /></td>
					</form>
				<?
				}//fin if
				?>
			</tr>
<?
	}//fin while
?>
		</tbody>
	</table>
<?
}

//Si la personne connecté posséde des droits plus évolué (si c'est le responsable de l'accompagnement éducatif)
if($_SESSION['droit']==1)
{//début if
	?>
	<!-- Formulaire de demande d'ajout d'élève -->
	<form name="demandeAjoutEleveAtelier" method="POST" action="">
	<input type="submit" name="action" value="Ajouter un élève" />
	<form>

	<?
	//Si le formulaire de demande d'ajout a été posté
	if(isset($_POST['action']) && $_POST['action']=="Ajouter un élève")
	{//début if
		?>
		<!-- Formulaire de filtre par classe -->
		<form name="filtreParClasse" method="POST" action="">
		<?
		listeClasse();	
		?>
		<input type="submit" name="action" value="Suivant" />
		</form>
		<?
	}//fin if

	//Si le formulaire de filtre par classe a été posté
	if(isset($_POST['action']) && $_POST['action']=="Suivant")
	{//début if
		?>
		<!-- Formulaire d'ajout d'un élève -->
		<form name="formAjoutEleve" method="POST" action="">
		<?
		listeTousLesElevesSelonUneClasse($_POST['lstClasse']);
		?>
		<input type="submit" name="action" value="ok !" />
		</form>
	<?
	}//fin if
}//fin if
?>
	<!-- Lien de navigation entre les pages -->
	<p><a href="menu.php">Revenir au menu principal</a></p>
	<p><a href="rechercherEleve.php">Rechercher une élève</a></p>
	<p><a href="connexion.php">Déconnexion</a></p>
<?
include ('footer.html');//Affiche le pied page
?>
