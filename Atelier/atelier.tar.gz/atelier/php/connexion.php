<?php
include ('header.html');//pour l'en-tête html
include ('fonction.php');//pour les fonctions

//Si les variables session de log existe déjà
if(isset($_SESSION['log']) && isset($_SESSION['mdp']))
{
	//On détruit toutes les variables sessions
	session_destroy();
}

//Si le formulaire a été posté
if(isset($_POST['action']) && $_POST['action']=="Se connecter")
{//début if
	//fonction qui vérifie l'identité de la personne qui se connecter
	authentification();
}//fin if

?>
	<!-- Formulaire de connexion -->
	<form name="formConnexion" method="POST" action="connexion.php">
		<p>Identifiant : <input type="text" name="inputId" placeholder="Votre identifiant" /><p>
		<p>Mot de passe : <input type="password" name="inputMdp" placeholder="Votre mot de passe" /></p>
		<input type="submit" name="action" value="Se connecter" /><!-- Bouton -->
	</form>
<?php
	include ('footer.html');//pour le pied de page html
	//fin du php
?>
