<?php
include ('header.html');//pour l'en-tête html
include ('fonction.php');//pour l'appel des fonctions

//Vérifie si un utilisateur est connecté
verifLog();

	//Si le formulaire a été posté
	if(isset($_POST['action']) && $_POST['action']=="Modifier")
	{
		$_SESSION['atelier']=$_POST['atelierChoisi'];
		unset($_SESSION['trimestre']);
		//redirection vers la page
		header('location:gestionAtelier.php');
	}
?>
<h1>Gestion atelier</h1>
<?
//Si l'utilisateur connecté est le responsable de l'accompagnement éducatif
if($_SESSION['droit']==1)
{//début if
	//Requête pour lister tous les ateliers
	$requete="SELECT ateId, ateLibelle, ateJour FROM Atelier;";
	$resultat=mysql_query($requete);
	?>
	<table>
		<thead>
			<tr>
				<th>id</th>
				<th>Libelle</th>
				<th>Jour</th>
				<th>...</th>
			</tr>
		</thead>
		<tbody>
	<?
	//Boucle qui parcours les occurences
	while($maLigne=mysql_fetch_array($resultat))
	{
	?>
			<tr>
				<td><?=$maLigne["ateId"]?></td>
				<td><?=$maLigne["ateLibelle"]?></td>
				<td><?=$maLigne["ateJour"]?></td>
				<!-- Formulaire pour accéder à la page de modification de l'atelier -->
				<form name="modifAtelier" method="POST" action="">
				<input type="hidden" name="atelierChoisi" value="<?=$maLigne["ateId"]?> " />
				<td><input type="submit" name="action" value="Modifier" /></td><!-- Bouton -->
				</form>				
			</tr>	
	<?
	}
	?>
		</tbody>
	</table>
<?
}
else
{
	//Rédaction de la requête pour les ateliers du responsable connecté
	$requete="SELECT ateId, ateLibelle, ateJour FROM Atelier natural join Responsable WHERE respId='".$_SESSION['log']."';";
	$resultat=mysql_query($requete);
	//Ranger le résultat dans un tableau
	?>
	<!-- Formulaire pour accéder à la modification de l'atelier -->
	<form name="modifierAtelier" method="POST" action="">
	<table><!-- Création du tableau pour correctement organisé les valeurs extraite de la base -->
		<thead>
			<tr>
				<th>Id</th>
				<th>Libelle</th>
				<th>Jour</th>
				<th>...</th>
			</tr>				
		</thead>
		<tbody>
	<?
	//boucle qui parcours les occurences de la base
	while($maLigne=mysql_fetch_array($resultat))
	{//début while
	?>
			<tr>
				<td><?=$maLigne["ateId"]?></td>
				<td><?=$maLigne["ateLibelle"]?></td>
				<td><?=$maLigne["ateJour"]?></td>
				<td><input type="submit" name="action" value="Modifier" /></td><!-- Bouton -->
				<input type="hidden" name="atelierChoisi" value="<?=$maLigne["ateId"]?>" />
			</tr>
	</form>
	<?	
	}//fin while
}
?>
	<!-- Lien pour navigué entre les pages -->
	<p><a href="rechercherEleve.php">Faire une recherche d'un élève</a></p>
	<p><a href="connexion.php">Déconnexion</a></p>
<?
include ('footer.html');//pour le pied de page html
?>
