<?php
include ('parametre.php');//Inclusion des paramètre de connexion à la base de données

// Fonction de conversion de date du format informatique (AAAA-MM-JJ) vers le format français (JJ/MM/AAAA).
function dateINFO2FR($date)
{//début fonction
	$date = explode('-', $date);
	$date = array_reverse($date);
	$date = implode('/', $date);
	return $date;
}//fin fonction

//Fonction qui permet, dans un soucis de lecture, de transformet le zero d'un id de classe en terminal
function siTerminal($idClasse)
{//début fonction
	//Si l'id de classe est égale à "0"
	if($idClasse[0]=="0")
	{//début if
		//Remplacement du "0" par le mot "terminal"
		$terminal="terminal".substr($idClasse,-1);
		return $terminal;
	}//fin if
	else
	{//début else
		return $idClasse;
	}//fin else
}//fin fonction

//Fonction s'assure de l'identité de la personne qui se connecter
function authentification()
{//début fonction
	//Récupération des données postées
	$log=$_POST['inputId'];
	$mdp=$_POST['inputMdp'];
	//Requête pour les données de la base concernant la personne qui essaie de se connecter
	$requete="SELECT respMdp, respNivDroit FROM Responsable WHERE respId='".$log."';";
	$resultat=mysql_query($requete);
	$row=mysql_fetch_array($resultat);
	
	if($row["respMdp"]==$mdp)
	{//début if
		//Stockage des valeurs de la base dans des variables sessions
		$_SESSION['log']=$log;
		$_SESSION['mdp']=$mdp;
		$_SESSION['droit']=$row["respNivDroit"];
		//Redirection vers la page
		header("location:menu.php");
	}//fin if
	else
	{//début else
		echo("<h1>Erreur de connexion</h1>");
	}//fin else
}//fin fonction

//fonction qui vérifie que la personne est bien connecté
function verifLog()
{//début fonction
	//Si les variables log et mdp existe
	if(isset($_SESSION['log']) && isset($_SESSION['mdp']))
	{//début if
		$requete="SELECT respId, respMdp FROM Responsable WHERE respId='".$_SESSION['log']."';";
		$resultat=mysql_query($requete);
		$row=mysql_fetch_array($resultat);
		if(($row["respId"]!=$_SESSION['log']) || ($row['respMdp']!=$_SESSION["mdp"]))
		{//début if
			header("location:connexion.php");
		}//fin if
	}//fin if
	else
	{//début else
		header("location:connexion.php");
	}//fin else
}//fin fonction

//Fonction qui permet de connaitre le nom de l'atelier choisi
function connaitreNomAtelier()
{//début fonction
	//Requête pour récupérer le nom de l'atelier
	$requete="SELECT ateLibelle FROM Atelier WHERE ateId='".$_SESSION['atelier']."';";
	$resultat=mysql_query($requete);
	$row=mysql_fetch_array($resultat);
	$nom=$row["ateLibelle"];
	return $nom;
}//fin fonction

//Fonction qui supprime les élèves sélectionnés parmit la liste des élèves qui participe ou plus précisement qui participé à l'atelier
function supprimerEleve()
{//début fonction
	//Requête pour supprimer l'élève de l'atelier pour le trimestre donné
	$requete="DELETE FROM Affectation WHERE elvId='".$_POST['hiddenElvId']."' AND trimesId='".$_SESSION['trimestre']."' AND ateId='".$_SESSION['atelier']."';";
	mysql_query($requete);
	echo("<h2>Suppression effectué</h2>");
}//fin fonction

//Fonction qui modifie une appréciation si il y en a déjà une 
function modificationAppreciation($idEleve, $appreciationModifie)
{//début fonction
	//Requête de modification de données, plus précisement de la modification de l'appréciation
	$requete="UPDATE Affectation SET affAppreciation='".$appreciationModifie."' WHERE elvId='".$idEleve."' AND ateId=".$_SESSION['atelier']." AND trimesID='".$_SESSION['trimestre']."';";
	//Exécution de la requête
	mysql_query($requete);
}//fin fonction


//fonction qui sait si c'est un ajout d'une appréciation ou la modification d'une appréciation
function ajoutOuModif()
{//début fonction
	//Récupération de l'id élève
	$eleve=$_POST["hiddenElvId"];
	//Récupération de l'appréciation
	$appreciation=$_POST["inputAppreciation"];
	//Rendre la chaîne propre
	$appreciation=clearString($appreciation);
	//Appel de la fonction de modification
	modificationAppreciation($eleve, $appreciation);
	echo("<h2>Appréciation prit en compte</h2>");
}//fin fonction

//Fonction qui rend la chaine de l'appréciation propre pour qu'elle soit inséré dans la base de données
// Param : la chaine qu'il faut rendre potable pour la base de données
function clearString($laChaineARendrePropre)
{//début fonction
	$laChaineARendrePropre=addslashes($laChaineARendrePropre);
	return $laChaineARendrePropre;
}//fin fonction

//fonction qui génére une liste déroulante de tous les élèves de la base
function listeTousLesEleves()
{//début fonction
	//requete d'extraction de tous les élèves de la base
	$requete="SELECT elvId, elvNom, elvPrenom, classeId FROM Eleves ORDER BY elvNom, elvPrenom;";
	$resultat=mysql_query($requete);
	?>
	<!-- liste déroulante -->
	<select name="lstEleves">
	<?
	//boucle qui parcours les occurences
	while($maLigne=mysql_fetch_array($resultat))
	{//début while
		?>
			<!-- option de la liste déroulante -->
			<option value="<?=$maLigne["elvId"]?>" >
				<!-- les options sont correctement rangés dans un table -->
				<table>
					<tbody>
						<tr>
							<td><?echo($maLigne["elvNom"]);?></td>
							<td><?echo($maLigne["elvPrenom"]);?></td>
							<td><?echo($maLigne["classeId"]);?></td>
						</tr>
					</tbody>
				</table>
			</option>
		<?
	}//fin while
	?>
	</select>
	<?
}//fin fonction

//fonction qui génére une liste déroulante de tous les élèves de la base, selon une classe choisi
function listeTousLesElevesSelonUneClasse($idClasse)
{//début fonction
	//requete d'extraction de tous les élèves de la base
	$requete="SELECT elvId, elvNom, elvPrenom FROM Eleves WHERE classeId='".$idClasse."' ORDER BY elvNom, elvPrenom;";
	$resultat=mysql_query($requete);
	?>
	<!-- liste déroulante -->
	<select name="lstElevesParClasse">
	<?
	//boucle qui parcours les occurences
	while($maLigne=mysql_fetch_array($resultat))
	{//début while
		?>
			<!-- option de la liste déroulante -->
			<option value="<?=$maLigne["elvId"]?>" >
				<!-- les options sont correctement rangés dans un table -->
				<table>
					<tbody>
						<tr>
							<td><?echo($maLigne["elvNom"]);?></td>
							<td><?echo($maLigne["elvPrenom"]);?></td>
						</tr>
					</tbody>
				</table>
			</option>
		<?
	}//fin while
	?>
	</select>
	<?
}//fin fonction

//fonction qui permet d'ajouter une élève à un atelier
function ajoutEleve($atelier, $eleve)
{//début fonction

	//Réquête d'insertion dans la base de données, pour affecter un élève à un atelier, selon un trimestre
	$requete="INSERT INTO Affectation(elvId, ateId, trimesId) VALUES('".$eleve."', '".$atelier."','".$_SESSION['trimestre']."');";
	mysql_query($requete);
	//Message
	echo("<h2>Ajout de l'élève a réussi</h2>");

}//fin fonction

//fonction qui génére une liste déroulante des classes de la base données
function listeClasse()
{//début fonction
	//Reuqête d'extraction des données
	$requete="SELECT classeId FROM Classe;";
	$resultat=mysql_query($requete);
	?>
	<!-- Liste déroulante -->
	<select name="lstClasse">
	<option value=""></option>
	<?
	//Boucle qui parcours les occurences de la base de données
	while($maLigne=mysql_fetch_array($resultat))
	{//début while
		$classe=siTerminal($maLigne["classeId"]);
		//si c'est une classe de terminal, remplacé le "0" par terminal
		?>
		<option value="<?=$maLigne["classeId"]?>" ><?echo($classe);?></option>
		<?
	}//fin while
	?>
	</select>
	<?
}//fin fonction

//fonction qui génére une liste déroulante des ateliers du responsable
function listeAtelierResponsable()
{//début fonction
	//Rédaction de la requête qui permet de connaitre de tous les ateliers de la base de données
	$requete="SELECT ateId, ateLibelle FROM Atelier NATURAL JOIN Responsable WHERE respId='".$_SESSION['log']."';";
	$resultat=mysql_query($requete);
	
	//création de la liste déroulante
	?>
	<select name="lstAtelierResp">
	<option value=""></option>
	<?
	//boucle qui parcours les occurences
	while($maLigne=mysql_fetch_array($resultat))
	{//début while
		?>
		<option value="<?=$maLigne["ateId"]?>" ><?echo $maLigne["ateLibelle"];?></option>
		<?		
	}//fin while
	?>
	</select>
	<?
}//fin fonction

//fonction qui génére une liste déroulante des trimestres
function listeTrimestre()
{//début fonction

	if(isset($_POST['lstTrimestre']))
	{
		$_SESSION['trimestre']=$_POST['lstTrimestre'];
	}
	//Liste déroulante
	?>
	<select name="lstTrimestre">
		<?
		for($i=1;$i<4;$i++)
		{//début for
			if(isset($_SESSION['trimestre']) && $_SESSION['trimestre']=="t".$i)
			{//début if
				echo("<option value=\"t".$i."\" selected >Trimestre ".$i."</option>");
			}//fin if
			else
			{//début else
				echo("<option value=\"t".$i."\">Trimestre ".$i."</option>");
			}//fin else
		}//fin for
		?>
	</select>
	<?
}//fin fonction
?>
