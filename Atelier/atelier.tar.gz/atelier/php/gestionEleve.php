<?php
include ('header.html');//En-tête html
include ('fonction.php');//Pour utiliser des fonctions

//Si la personne connecté est la reponsable de l'accompagnement éducatif
if(isset($_SESSION['droit']) && $_SESSION['droit']==1)
{//début if
	//Si le formulaire de modification des affectations a été posté
	if(isset($_POST['action']) && $_POST['action']=="Modifier")
	{//déubut if

		//Boucle qui parcours les cases cochées
		if(isset($_POST['tabAtelier']))
		{//début if
			foreach($_POST['tabAtelier'] as $element)
			{//début foreach
				//J'affecte l'élève à tous les ateliers cochés pour le trimestre choisi
				$requete="INSERT INTO Affectation(elvId,ateId,trimesId) VALUES('".$_POST['elvId']."','".$element."','".$_SESSION['trimestre']."');";
				mysql_query($requete);
			}//fin foreach
		}//fin if

		//Requête pour voir tous les ateliers de l'élève selont le trimestre choisi
		$requete="SELECT elvId, ateId, trimesId FROM Affectation WHERE elvId='".$_POST['elvId']."' AND trimesId='".$_SESSION['trimestre']."';";
		$resultat=mysql_query($requete);

		//boucle parcours les occurences, de la précédente requête
		while($maLigne=mysql_fetch_array($resultat))
		{//début while

			//Iniatilisation d'une variable booléene
			$bool=false;
		
			if(isset($_POST['tabAtelier']))
			{//début if
				//boulce qui parcours les cases cochées
				foreach($_POST['tabAtelier'] as $element)
				{//début foreach
					//si la case à coché à la même valeur que celle dans la table
					if($element==$maLigne['ateId'])
					{//début if
						//chagement de la valeur booléene
						$bool=true;
					}//fin if
				}//fin foreach
			}//fin if

			//Si la valeur du booléen n'a pas changé, supprimer dans la base de données l'atelier pour l'élève choisi et pour le trismestre choisi
			if($bool==false)
			{//début if
				//Requête de suppression de l'élève d'un atelier
				$requete="DELETE FROM Affectation WHERE ateId='".$maLigne["ateId"]."' AND elvId='".$_POST['elvId']."' AND trimesId='".$_POST['trimestreId']."';";
				mysql_query($requete);
			}//fin if
		}//fin while
		echo("<h2>Modification enregistrée</h2>");
	}//fin if

	//Partie du code pour récupérer quoi qu'il arrive l'id de l'élève, car soit on arriv de la page rechercherEleve.php ou soit cette page a été rechargée
	//Si on vient de la page "rechercherEleve.php"
	if(isset($_POST['hiddenIdEleve']))
	{//début if
		$eleve=$_POST['hiddenIdEleve'];
		unset($_SESSION['trimestre']);
	}//fin if
	if(isset($_POST['elvId']))
	{//début if
		$eleve=$_POST['elvId'];
	}//fin if

	//Requête pour avoir les informations de l'élèves
	$requete="SELECT Eleves.*, ateId FROM Eleves NATURAL JOIN Affectation WHERE elvId='".$eleve."';";
	$resultat=mysql_query($requete);
	$maLigne=mysql_fetch_array($resultat);
	//Convertion du format de la date (US-->FR)
	$date=dateINFO2FR($maLigne["elvDateNaissance"]);
	//Si l'élève est dans une classe de terminal, la fonction renvoie "terminal" à la place de "0"
	$classe=siTerminal($maLigne["classeId"]);
	?>
	<p>Nom : <?=$maLigne["elvNom"]?></p>
	<p>Prenom : <?=$maLigne["elvPrenom"]?></p>
	<p>Date naissance : <?=$date?></p>
	<p>Adresse : <?=$maLigne["elvAdresse1"]?></p>
	<?
	//Si le champs "elvAdresse2" n'est pas vide, on l'affiche
	if(!empty($maLigne["elvAdresse2"]))
	{//début if
	?>
	<p><?=$maLigne["elvAdresse2"]?></p>
	<?
	}//fin if
	?>
	<p>Code postal : <?=$maLigne["elvCp"]?></p>
	<p>Ville : <?=$maLigne["elvVille"]?></p>
	<p>Mail : <?=$maLigne["elvMail"]?></p>
	<p>Classe : <?=$classe?></p>
	<p></p>
	<p>
	<!-- Formulaire pour le choix du trimestre -->
	<form name="choixTrimestre" method="POST" action="">
	<?
	listeTrimestre();
	?>
	<input type="hidden" name="elvId" value="<?=$eleve?>" />
	<input type="submit" name="action" value="Suivant" />
	</form>
<?	
	//Si le formulaire a été posté
	if(isset($_POST['action']) && $_POST['action']=="Suivant")
	{//début if
		//Requête pour connaitre tous les ateliers du lycée
		$requeteAtelier="SELECT ateId, ateLibelle FROM Atelier;";
		$resultatAtelier=mysql_query($requeteAtelier);

		//Requête pour connaitre les ateliers auxquelles l'élève est inscrit
		$requeteAtelierEleve="SELECT ateId FROM Affectation WHERE elvId='".$eleve."' AND trimesId='".$_POST['lstTrimestre']."';";
		?>
		<!-- Formualire de modification des affectation-->
		<form name="gestionAffectationEleve" method="POST" action="">
		<input type="hidden" name="elvId" value="<?=$eleve?>" />
		<?
		//Boucle qui parcours les occurences de la base
		while($rowAtelier=mysql_fetch_array($resultatAtelier))
		{//début while
			$resultatAtelierEleve=mysql_query($requeteAtelierEleve);
			//Affichage des ateliers
			echo $rowAtelier["ateLibelle"];
			?>
			<input type="checkbox" name="tabAtelier[]" value="<?=$rowAtelier["ateId"]?>"
			<?
			//Boucle qui parcours les occurences de la base
			while($rowAtelierEleve=mysql_fetch_array($resultatAtelierEleve))
			{//début while
				if($rowAtelierEleve["ateId"]==$rowAtelier["ateId"])
				{//début if
					echo("checked");
				}//fin if		
			}//fin while
			?>
			/>
			<?
		}//fin while
		?>
	<input type="submit" name="action" value="Modifier" />
	</form>
	<!-- Formulaire pour générer le pdf bulletin -->
	<form name="genePDF" method="POST" action="genePDF.php">
	<input type="hidden" name="hiddenElvId" value="<?=$eleve?>" />
	<input type="submit" name="action" value="Générer le bulletin" />
	</form>
	<?
	}//fin if
?>
	<!-- Navigation dans les pages -->
	<p><a href="rechercherEleve.php">Faire une autre recherhce</a></p>
	<p><a href="menu.php">Revenir au menu principal</a></p>
	<p><a href="connexion.php">Déconnexion</a></p>
<?
	include ('footer.html');
}//fin if
else
{//début else
	header('location:menu.php');
}//fin else
?>
