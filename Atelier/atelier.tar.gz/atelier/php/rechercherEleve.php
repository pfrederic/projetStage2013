<?php
include ('header.html');
include ('fonction.php');

verifLog();

?>
	<form name="rechercheEleve" method="POST" action="">
		<p>Nom : <input type="text" name="searchElvNom" placeholder="Saississez un nom" /></p>
		<p>Prenom : <input type="text" name="searchElvPrenom" placeholder="Saississez un prenom" /></p>
		<p>Classe : <?listeClasse();?></p>
		<p><input type="submit" name="action" value="Rechercher" /></p>
	</form>
<?
if(isset($_POST['action']) && $_POST['action']=="Rechercher")
{//début if
	//Récupération des données postées
	$nom=$_POST['searchElvNom'];
	$prenom=$_POST['searchElvPrenom'];
	$classe=$_POST['lstClasse'];
	$where=" WHERE";
	if(!empty($nom))
	{//début if
		$where.=" elvNom='".$nom."'";
			if(!empty($prenom))
			{//début if
				$where.=" AND elvPrenom='".$prenom."'";
			}//fin if
			if(!empty($classe))
			{//début if
				$where.=" AND classeId='".$classe."'";
			}//fin if
	}//fin if
	else
	{//début else
			if(!empty($prenom))
			{//début if
				$where.=" elvPrenom='".$prenom."'";
				if(!empty($classe))
				{//début if
					$where.=" AND classeId='".$classe."'";
				}//fin
			}//fin if
			else
			{//début else
				if(!empty($classe))
				{//début if
					$where.=" classeId='".$classe."'";
				}//fin if
			}//fin else
	}//fin else
	$where.=";";
	$requete="SELECT Eleves.* FROM Eleves ";
	$requete.=$where;
	
	$resultat=mysql_query($requete);
	?>
	<table>
		<thead>
			<tr>
				<th>Nom</th>
				<th>Prenom</th>
				<th>Date naissance</th>
				<th>Adresse</th>
				<th>Code postal</th>
				<th>Ville</th>
				<th>Mail</th>
				<th>Classe</th>
				<?
				if($_SESSION['droit']==1)
				{
				?>
				<th>Bouton</th>
				<?
				}
				?>
			</tr>
		</thead>
		<tbody>
	<?
	while($maLigne=mysql_fetch_array($resultat))
	{
	$date=dateINFO2FR($maLigne["elvDateNaissance"]);
	$classe=siTerminal($maLigne["classeId"]);
	?>
			<tr>
				<td><?=$maLigne["elvNom"];?></td>
				<td><?=$maLigne["elvPrenom"];?></td>
				<td><?=$date;?></td>
				<td><?=$maLigne["elvAdresse1"];?></td>
				<?
				if(!empty($maLigne["elvAdresse2"]))
				{
					?>
					<td><?=$maLigne["elvAdresse2"];?></td>
					<?
				}
				?>
				<td><?=$maLigne["elvCp"];?></td>
				<td><?=$maLigne["elvVille"];?></td>
				<td><?=$maLigne["elvMail"];?></td>
				<td><?=$classe;?></td>
				<?
				if($_SESSION['droit']==1)
				{
				?>
				<form name="redirectionAffectationAtelier" method="POST" action="gestionEleve.php">
				<input type="hidden" name="hiddenIdEleve" value="<?=$maLigne["elvId"]?>" />
				<td><input type="submit" name="action" value="Select" /></td>
				</form>
				<?
				}
				?>
			</tr>
	<?
	}		

}//fin if
?>
	<p><a href="menu.php">Revenir au menu principal</a></p>
	<p><a href="connexion.php">Déconnexion</a></p>
<?
include ('footer.html');
?>
