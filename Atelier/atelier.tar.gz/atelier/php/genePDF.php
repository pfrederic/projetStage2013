<?php
include ('fonction.php');//Pour utiliser certaines fonctions
require('fpdf.php');//Nécessaire à la création du pdf

class PDF extends FPDF
{//début classe
//En-tête de la page
function Header()
{//début fonction
	//Logo
	$this->Image('../image/bulletin3.jpg',20,6,60);
	//Police Arial gras 15
	$this->SetFont('Arial','B',15);
	//Décalage à droite
	$this->Cell(110);
	//Titre encadré
	$this->Cell(80,10,'Bulletin trimestriel des ateliers',1,0,'C');
	//Saut de ligne
	$this->Ln(20);
}//fin fonction

//Pied de la page
function Footer()
{//début fontion
	//Position à 1.5cm du bas
	$this->SetY(-15);
	//Police Arial italique 8
	$this->SetFont('Arial','I',8);
	//Numéro de page
	$this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}//fin fonction

//Tableau qui range les informations d'un élève dans un tableau
function TableEleve($headerEleve)
{//début fonction

	//Requête pour les données de l'élèves
	$requete="SELECT elvNom, elvPrenom, elvDateNaissance, elvAdresse1, elvAdresse2, elvCp, elvVille, classeId FROM Eleves WHERE elvId='".$_POST["hiddenElvId"]."';";
	$resultat=mysql_query($requete);
	$maLigne=mysql_fetch_array($resultat);

	//Changement encodage des données des champs, modification de la classe pour le format francais, et remplaçage du "0" par "terminal"
	$nom=utf8_decode($maLigne["elvNom"]);
	$prenom=utf8_decode($maLigne["elvPrenom"]);
	$date=dateINFO2FR($maLigne["elvDateNaissance"]);
	$adresse1=utf8_decode($maLigne["elvAdresse1"]);
	$adresse2=utf8_decode($maLigne["elvAdresse2"]);
	$ville=utf8_decode($maLigne["elvVille"]);
	$classe=siTerminal($maLigne["classeId"]);

	//Tableau
	//En-tête
	$this->Cell(95,11,'Nom et '.utf8_decode('Prénom'),'1L',0,'C');
	//Données
	$this->Cell(95,11,$nom.' '.$prenom,'1L',0,'C');
	//Saut de ligne
	$this->Ln();
	//En-tête
	$this->Cell(95,11,'Date de naissance','1L',0,'C');
	//Données
	$this->Cell(95,11,$date,'1L',0,'C');
	//Saut de ligne
	$this->Ln();
	//En-tête
	$this->Cell(95,11,'Adresse','1L',0,'C');
	//Données
	$this->Cell(95,11,$adresse1.' '.$adresse2,'1L',0,'C');
	//Saut de ligne
	$this->Ln();
	//En-tête
	$this->Cell(95,11,'Code postal','1L',0,'C');
	//Données
	$this->Cell(95,11,$maLigne["elvCp"],'1L',0,'C');
	//Saut de ligne
	$this->Ln();
	//En-tête
	$this->Cell(95,11,'Ville','1L',0,'C');
	//Données
	$this->Cell(95,11,$ville,'1L',0,'C');
	//Saut de ligne
	$this->Ln();
	//En-tête
	$this->Cell(95,11,'Classe','1L',0,'C');
	//Données
	$this->Cell(95,11,$classe,'1L',0,'C');

	//Gros saut de lignes
	$this->Ln(13);	
}//fin fonction

//fonction qui permet d'afficher la période (trimestre) du bulletin
function periode()
{//début fonction
	$requete="SELECT trimesId, extract(YEAR from trimesDateFin) as annee FROM Trimestre WHERE trimesId='".$_SESSION['trimestre']."';";
	$resultat=mysql_query($requete);
	$maLigne=mysql_fetch_array($resultat);
	$trimestre=substr($maLigne["trimesId"],-1);
	$this->Cell(95,11,utf8_decode('Période'),'1L',0,'C');
	$this->Cell(95,11,'trimestre '.$trimestre.' - '.$maLigne["annee"],'1L',0,'C');
	$this->Ln(30);
}//fin fonction

//Tableau des appréciations
function FancyTable($header)
{//début fonction
	//Couleurs, épaisseur du trait et police grasse
	$this->SetFillColor(255,0,0);
	$this->SetTextColor(255);
	$this->SetDrawColor(128,0,0);
	$this->SetLineWidth(.3);
	$this->SetFont('','B');
	//En-tête
	$w=array(35,35,0);
	for($i=0;$i<count($header);$i++)
		$this->Cell($w[$i],7,$header[$i],1,0,'C',true);
	$this->Ln();
	//Restauration des couleurs et de la police
	$this->SetFillColor(224,235,255);
	$this->SetTextColor(0);
	$this->SetFont('');
	//Données
	$fill=false;
	//Requête pour données sur élève
	$requete="SELECT ateLibelle, affAppreciation, respNom FROM Atelier NATURAL JOIN Affectation NATURAL JOIN Responsable WHERE elvId='".$_POST['hiddenElvId']."' AND trimesId='".$_SESSION['trimestre']."';";
	$resultat=mysql_query($requete);
	//Boucle qui parcours les occurences de la base de données
	while($maLigne=mysql_fetch_array($resultat))
	{//début while
		//données appréciation, dans tableau
		$this->Cell($w[0],11,utf8_decode($maLigne["ateLibelle"]),'1L',0,'C',$fill);
		$this->Cell($w[1],11,utf8_decode($maLigne["respNom"]),'1L',0,'C',$fill);
		$this->MultiCell($w[2],11,utf8_decode($maLigne["affAppreciation"]),'1L','L',$fill);
		$fill=!$fill;
	}//fin while
	//Trait de terminaison
	$this->Cell(array_sum($w),0,'','T');
}//fin fonction
}//fin classe
//Instanciation de la classe dérivée
$pdf= new PDF();
//Titre des colonnes
$header=array('Atelier','Responsable','Appreciation');
$headerEleve=array('Nom et Prenom','Date de naissance','Adresse','Code postal','Ville','Classe');
//Chargement des données
$pdf->SetFont('Arial','',14);
$pdf->AddPage();
$pdf->AliasNbPages();
$pdf->TableEleve($headerEleve);
$pdf->periode();
$pdf->FancyTable($header);
$pdf->Output();
?>
