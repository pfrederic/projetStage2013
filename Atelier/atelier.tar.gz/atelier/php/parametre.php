<?php
//Initialisation des variables session
session_start();
	//données de connexion
	$host="127.0.0.1";//ip de la bdd
	$user="etudiant";//utilisateur de la bbd
	$mdp="ini01";//mot de passe
	$base="bd_atelier";//base sélectionnée

	//Connexion de la base
	$link=mysql_connect($host,$user,$mdp);
	//Si la connexion ne réussi pas
	if(!$link)
	{//début if
		echo mysql_error();
	}//fin if
	else
	{//début else
		mysql_select_db($base,$link);
	}//fin else
?>
