-- Script : Modification de la base de données, pour prendre en compte de nouveau besoins
-- Auteur : F.Pignoly (stagiaire)
-- Date de création : 18/06/2013
-- Date dernière modification : 18/06/2013

-- Gestion des trismestres
CREATE TABLE Trimestre
 (
 trimesId		varchar(2) primary key,
 trimesDateDebut	date,
 trimesDateFin		date
 ) engine=innodb;

-- Suppression de la clé primaire
ALTER TABLE Affectation
DROP PRIMARY KEY;

-- Ajout d'un champs dans la table "Affectation"
ALTER TABLE Affectation
ADD COLUMN trimesId varchar(2);

-- Ajout contrainte d'intégrité référentielle
ALTER TABLE Affectation
ADD FOREIGN KEY (trimesId) REFERENCES Trimestre(trimesId);

-- Création de la nouvelle clé primaire
ALTER TABLE Affectation
ADD PRIMARY KEY(elvId, ateId, trimesId);

-- Ajour du jeu d'essai
INSERT INTO Trimestre VALUES("t1","2012-09-05","2012-11-30"),("t2","2012-12-01","2013-03-31"),("t3","2013-04-01","2013-07-01");

UPDATE Affectation SET trimesId="t1";

-- Ajout d'un responsable qui est en fait l'accompagnatrice éducatif, qui à des droits différents que les responsables,
-- elle peut notamment ajouter ou supprimer les élèves
ALTER TABLE Responsable
ADD COLUMN respNivDroit tinyint;

UPDATE Responsable SET respNivDroit=0;

INSERT INTO Responsable VALUES("respo","accompagnatrice","educatif","admin","stjo@orange.fr",1);
