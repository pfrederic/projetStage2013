-- Script : Implémetation d'un jeu d'essaie
-- Auteur : F.Pignoly (stagiaire)
-- Date création : 12/06/2013
-- Date dernière modification : 12/06/2013

-- Table : Classe
DELETE FROM Classe;
INSERT INTO Classe VALUES ("6A"),("6B"),("6C"),("6E"),
			  ("5A"),("5B"),("5C"),("5E"),
			  ("4A"),("4B"),("4C"),("4E"),
			  ("3A"),("3B"),("3C"),("3E"),
			  ("2A"),("2B"),("2C"),("2E"),
			  ("1A"),("1B"),("1C"),("1E"),
			  ("0A"),("0B"),("0C"),("0E");

-- Table : Eleves
DELETE FROM Eleves;
INSERT INTO Eleves VALUES ("E0001","Alberto","Hugo","1993-07-25","14 rue d'abon",NULL,"05000","GAP",1,"hugo.alberto@gmail.com","0B"),
			  ("E0002","Pignoly","Frédéric","1994-02-02","11 rue montclair",NULL,"05000","GAP",0,"pignoly.frederic@gmail.com","1E"),
			  ("E0003","Chirac","Bernadette","2000-09-18","143 rue des fleurs",NULL,"04000","MONTGARDIN",0,"nan3tt3du04@skyblog.com","4B");

-- Table : Reponsable
DELETE FROM Responsable;
INSERT INTO Responsable VALUES ("R0001","Buscat","Jérôme","ini01","jbuscat@gmail.com",0),
			       ("R0002","Lopes","Loris","ini02","lolo@gmail.com",0),
			       ("R0003","Millon","Mika","ini03","mimi@gmail.com",0),
			       ("respo","accompagnatrice","educatif","admin","stjo@orange.fr",1);

-- Table : Atelier
DELETE FROM Atelier;
INSERT INTO Atelier VALUES (1,"Modélisme","jeudi","R0001"),
			   (2,"Diaporama","lundi","R0003"),
			   (3,"Informatique","mardi","R0002");

-- Table : Trimestre
INSERT INTO Trimestre VALUES("t1","2012-09-05","2012-11-30"),("t2","2012-12-01","2013-03-31"),("t3","2013-04-01","2013-07-01");

-- Table : Affectation
DELETE FROM Affectation;
INSERT INTO Affectation VALUES ("E0003",2,"De l'imagination ... pour faire des bétises pour ne pas dire ...","t1"),
			       ("E0002",1,"A réaliser une maquette d'un char, enfin d'une carcasse de char, après l'explosion d'un IED","t2"),
			       ("E0001",3,"Du goût et du talent pour le web-desing, un gamin très prometteur","t3");
