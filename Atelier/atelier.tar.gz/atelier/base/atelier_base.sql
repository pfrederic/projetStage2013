-- Script : Création de la base de données pour la gestion des ateliers
-- Auteur : F.Pignoly (stagiaire)
-- Date création : 12/06/2013
-- Date dernière modification : 12/06/2013
-- Moteur : MySql

-- Suppression de la base
DROP DATABASE if exists bd_atelier;

-- Création de la base
CREATE DATABASE bd_atelier CHARACTER SET = "utf8";

-- Utilisation de la base
USE bd_atelier;

-- Création des tables
-- Table : Eleves
CREATE TABLE Eleves
 (
 elvId 			varchar(5) primary key,
 elvNom 		varchar(25) NOT NULL,
 elvPrenom 		varchar(30) NOT NULL,
 elvDateNaissance 	date NOT NULL,
 elvAdresse1 		varchar(50) NOT NULL,
 elvAdresse2 		varchar(50),
 elvCp 			varchar(5) NOT NULL,
 elvVille		varchar(40) NOT NULL,
 elvRedoublant		tinyint NOT NULL, -- 0 -> Si non redoublant | 1 -> Si redoublant
 elvMail		varchar(60),
 classeId		varchar(3)
 ) engine=innodb;

-- Table : Classe
CREATE TABLE Classe
 (
 classeId varchar(3) primary key
 ) engine = innodb;
-- Table : Responsable
CREATE TABLE Responsable
 (
 respId 		varchar(5) primary key,
 respNom 		varchar(25) NOT NULL,
 respPrenom		varchar(30) NOT NULL,
 respMdp		varchar(255) NOT NULL,
 respMail		varchar(60) NOT NULL,
 respNivDroit		tinyint
 ) engine=innodb;

-- Table : Atelier
CREATE TABLE Atelier
 (
 ateId 		smallint primary key,
 ateLibelle 	varchar(50) NOT NULL,
 ateJour	varchar(10) NOT NULL,
 respId 	varchar(5) NOT NULL
 ) engine=innodb;

-- Table : Affectation
CREATE TABLE Affectation
 (
 elvId			varchar(5),
 ateId			smallint,
 affAppreciation 	text,
 trimesId		varchar(2),
 PRIMARY KEY(elvId,ateId,trimesId)
 ) engine=innodb;

-- Table : Trimestre
CREATE TABLE Trimestre
 (
 trimesId		varchar(2) primary key,
 trimesDateDebut	date,
 trimesDateFin		date
 ) engine=innodb;


-- Ajout des contraintes d'intégrités référentielles
ALTER TABLE Atelier
ADD FOREIGN KEY (respId) REFERENCES Responsable(respId);

ALTER TABLE Affectation
ADD FOREIGN KEY (ateId) REFERENCES Atelier(ateId),
ADD FOREIGN KEY (elvId) REFERENCES Eleves(elvId);

ALTER TABLE Eleves
ADD FOREIGN KEY (classeID) REFERENCES Classe(classeId);

ALTER TABLE Affectation
ADD FOREIGN KEY (trimesId) REFERENCES Trimestre(trimesId);
